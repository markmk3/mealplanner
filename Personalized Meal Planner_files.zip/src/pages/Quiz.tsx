import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';

const Quiz = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    weight: '',
    height: '',
    goal: '',
    activityLevel: '',
    dietaryRestrictions: [] as string[],
    allergies: [] as string[],
    mealPreference: ''
  });
  
  const [loading, setLoading] = useState(false);

  const dietaryRestrictions = [
    'Vegetarian', 'Vegan', 'Pescatarian', 'Keto', 'Paleo', 'Gluten-Free', 'Dairy-Free', 'Low-Carb'
  ];
  
  const commonAllergies = [
    'Peanuts', 'Tree Nuts', 'Milk', 'Eggs', 'Wheat', 'Soy', 'Fish', 'Shellfish'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked } = e.target;
    if (checked) {
      setFormData(prev => ({
        ...prev,
        [name]: [...prev[name as keyof typeof prev] as string[], value]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: (prev[name as keyof typeof prev] as string[]).filter(item => item !== value)
      }));
    }
  };

  const nextStep = () => {
    setStep(step + 1);
    window.scrollTo(0, 0);
  };

  const prevStep = () => {
    setStep(step - 1);
    window.scrollTo(0, 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Store the form data in sessionStorage to access it in Results page
      sessionStorage.setItem('userData', JSON.stringify(formData));
      
      // Redirect to results page
      setTimeout(() => {
        navigate('/results');
      }, 1500);
    } catch (error) {
      console.error('Error submitting form:', error);
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="bg-green-600 px-6 py-4">
            <h1 className="text-xl font-bold text-white">Create Your Personalized Meal Plan</h1>
            <div className="mt-2 flex items-center">
              {[1, 2, 3, 4].map(num => (
                <div key={num} className="flex items-center">
                  <div className={`flex items-center justify-center h-8 w-8 rounded-full ${
                    step >= num ? 'bg-white text-green-600' : 'bg-green-500 text-white'
                  }`}>
                    {step > num ? (
                      <Check className="h-5 w-5" />
                    ) : (
                      <span>{num}</span>
                    )}
                  </div>
                  {num < 4 && (
                    <div className={`w-12 h-1 ${step > num ? 'bg-white' : 'bg-green-500'}`} />
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="px-6 py-8">
              {step === 1 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Basic Information</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                        Your Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        id="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="age" className="block text-sm font-medium text-gray-700">
                        Age
                      </label>
                      <input
                        type="number"
                        name="age"
                        id="age"
                        min="1"
                        max="120"
                        value={formData.age}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="gender" className="block text-sm font-medium text-gray-700">
                        Gender
                      </label>
                      <select
                        id="gender"
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="">Select your gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
              
              {step === 2 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Your Measurements</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="weight" className="block text-sm font-medium text-gray-700">
                        Weight (kg)
                      </label>
                      <input
                        type="number"
                        name="weight"
                        id="weight"
                        min="30"
                        max="300"
                        value={formData.weight}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="height" className="block text-sm font-medium text-gray-700">
                        Height (cm)
                      </label>
                      <input
                        type="number"
                        name="height"
                        id="height"
                        min="100"
                        max="250"
                        value={formData.height}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                  </div>
                </div>
              )}
              
              {step === 3 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Your Goals & Activity</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
                        What is your main goal?
                      </label>
                      <select
                        id="goal"
                        name="goal"
                        value={formData.goal}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="">Select your goal</option>
                        <option value="weight-loss">Weight Loss</option>
                        <option value="muscle-gain">Muscle Gain</option>
                        <option value="maintenance">Maintenance</option>
                        <option value="general-health">General Health</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="activityLevel" className="block text-sm font-medium text-gray-700">
                        Activity Level
                      </label>
                      <select
                        id="activityLevel"
                        name="activityLevel"
                        value={formData.activityLevel}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="">Select your activity level</option>
                        <option value="sedentary">Sedentary (little or no exercise)</option>
                        <option value="light">Lightly active (light exercise 1-3 days/week)</option>
                        <option value="moderate">Moderately active (moderate exercise 3-5 days/week)</option>
                        <option value="very-active">Very active (hard exercise 6-7 days/week)</option>
                        <option value="extra-active">Extra active (very hard exercise & physical job)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
              
              {step === 4 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">Dietary Preferences</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Do you have any dietary restrictions?
                      </label>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        {dietaryRestrictions.map(restriction => (
                          <div key={restriction} className="flex items-start">
                            <input
                              id={restriction.toLowerCase()}
                              name="dietaryRestrictions"
                              type="checkbox"
                              value={restriction}
                              onChange={handleCheckboxChange}
                              checked={formData.dietaryRestrictions.includes(restriction)}
                              className="h-4 w-4 text-green-500 border-gray-300 rounded focus:ring-green-500"
                            />
                            <label htmlFor={restriction.toLowerCase()} className="ml-2 text-sm text-gray-700">
                              {restriction}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Do you have any allergies?
                      </label>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        {commonAllergies.map(allergy => (
                          <div key={allergy} className="flex items-start">
                            <input
                              id={allergy.toLowerCase()}
                              name="allergies"
                              type="checkbox"
                              value={allergy}
                              onChange={handleCheckboxChange}
                              checked={formData.allergies.includes(allergy)}
                              className="h-4 w-4 text-green-500 border-gray-300 rounded focus:ring-green-500"
                            />
                            <label htmlFor={allergy.toLowerCase()} className="ml-2 text-sm text-gray-700">
                              {allergy}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="mealPreference" className="block text-sm font-medium text-gray-700">
                        Meal Frequency Preference
                      </label>
                      <select
                        id="mealPreference"
                        name="mealPreference"
                        value={formData.mealPreference}
                        onChange={handleChange}
                        required
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="">Select your preference</option>
                        <option value="three-meals">Three meals a day</option>
                        <option value="four-meals">Four meals a day</option>
                        <option value="five-meals">Five meals a day (including snacks)</option>
                        <option value="intermittent-fasting">Intermittent fasting</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="px-6 py-4 bg-gray-50 flex justify-between">
              {step > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  Back
                </button>
              )}
              
              {step < 4 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="ml-auto px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-green-600 hover:bg-green-700"
                >
                  Next
                  <ArrowRight className="ml-2 -mr-1 h-4 w-4 inline" aria-hidden="true" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={loading}
                  className={`ml-auto px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-green-600 hover:bg-green-700 ${loading ? 'opacity-75 cursor-not-allowed' : ''}`}
                >
                  {loading ? 'Generating Plan...' : 'Create My Meal Plan'}
                  {!loading && <ArrowRight className="ml-2 -mr-1 h-4 w-4 inline" aria-hidden="true" />}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
  