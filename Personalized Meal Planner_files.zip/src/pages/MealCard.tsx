import  { Utensils } from 'lucide-react';
import { Meal } from '../types';

type MealCardProps = {
  meal: Meal;
  onClick: () => void;
  isExpanded: boolean;
};

const MealCard = ({ meal, onClick, isExpanded }: MealCardProps) => {
  return (
    <div className="border rounded-lg overflow-hidden bg-white hover:shadow-md transition">
      <div 
        onClick={onClick}
        className="p-4 cursor-pointer flex justify-between items-center"
      >
        <div className="flex items-center">
          <div className="bg-green-100 p-2 rounded-full mr-3">
            <Utensils className="h-5 w-5 text-green-500" />
          </div>
          <div>
            <h3 className="font-medium text-gray-800">{meal.name}</h3>
            <p className="text-sm text-gray-500">{meal.type} • {meal.calories} kcal</p>
          </div>
        </div>
        <div className="text-gray-400">
          {isExpanded ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          )}
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-4 pb-4">
          <div className="flex flex-wrap -mx-2 mb-4">
            <div className="w-1/2 px-2 mb-2">
              <div className="bg-gray-50 p-2 rounded">
                <p className="text-xs text-gray-500">Protein</p>
                <p className="font-medium">{meal.protein}g</p>
              </div>
            </div>
            <div className="w-1/2 px-2 mb-2">
              <div className="bg-gray-50 p-2 rounded">
                <p className="text-xs text-gray-500">Carbs</p>
                <p className="font-medium">{meal.carbs}g</p>
              </div>
            </div>
            <div className="w-1/2 px-2">
              <div className="bg-gray-50 p-2 rounded">
                <p className="text-xs text-gray-500">Fat</p>
                <p className="font-medium">{meal.fat}g</p>
              </div>
            </div>
            <div className="w-1/2 px-2">
              <div className="bg-gray-50 p-2 rounded">
                <p className="text-xs text-gray-500">Calories</p>
                <p className="font-medium">{meal.calories} kcal</p>
              </div>
            </div>
          </div>
          
          <div className="mb-3">
            <h4 className="text-sm font-medium text-gray-700 mb-1">Ingredients:</h4>
            <ul className="text-sm text-gray-600 list-disc pl-5 space-y-1">
              {meal.ingredients.map((ingredient, idx) => (
                <li key={idx}>{ingredient}</li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-1">Instructions:</h4>
            <p className="text-sm text-gray-600">{meal.instructions}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MealCard;
  