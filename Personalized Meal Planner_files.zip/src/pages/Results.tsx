import  { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronUp, Download, PrinterIcon, Share2 } from 'lucide-react';
import { generateMealPlan } from '../services/openai';
import { MealPlan } from '../types';
import MealCard from '../components/MealCard';

const Results = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [mealPlan, setMealPlan] = useState<MealPlan | null>(null);
  const [expandedDay, setExpandedDay] = useState<string | null>(null);
  const [expandedMeals, setExpandedMeals] = useState<{[key: string]: string[]}>({});
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchMealPlan = async () => {
      try {
        const userData = sessionStorage.getItem('userData');
        
        if (!userData) {
          navigate('/quiz');
          return;
        }
        
        const parsedUserData = JSON.parse(userData);
        const plan = await generateMealPlan(parsedUserData);
        setMealPlan(plan);
        setLoading(false);
        
        // Expand the first day by default
        if (plan && plan.days && plan.days.length > 0) {
          setExpandedDay(plan.days[0].day);
          setExpandedMeals({[plan.days[0].day]: []});
        }
      } catch (error) {
        console.error('Error fetching meal plan:', error);
        setError('Failed to generate meal plan. Please try again.');
        setLoading(false);
      }
    };
    
    fetchMealPlan();
  }, [navigate]);
  
  const toggleDay = (day: string) => {
    if (expandedDay === day) {
      setExpandedDay(null);
    } else {
      setExpandedDay(day);
      if (!expandedMeals[day]) {
        setExpandedMeals({
          ...expandedMeals,
          [day]: []
        });
      }
    }
  };
  
  const toggleMeal = (day: string, mealType: string) => {
    if (expandedMeals[day]?.includes(mealType)) {
      setExpandedMeals({
        ...expandedMeals,
        [day]: expandedMeals[day].filter(m => m !== mealType)
      });
    } else {
      setExpandedMeals({
        ...expandedMeals,
        [day]: [...(expandedMeals[day] || []), mealType]
      });
    }
  };
  
  const handleDownload = () => {
    if (!mealPlan) return;
    
    // Create a text version of the meal plan
    let content = `NutriPlan - Your Personalized Meal Plan\n\n`;
    content += `Daily Nutritional Targets:\n`;
    content += `Calories: ${mealPlan.calories} | Protein: ${mealPlan.protein}g | Carbs: ${mealPlan.carbs}g | Fat: ${mealPlan.fat}g\n\n`;
    
    mealPlan.days.forEach(day => {
      content += `${day.day}\n`;
      content += `${'-'.repeat(day.day.length)}\n`;
      
      day.meals.forEach(meal => {
        content += `${meal.type}: ${meal.name}\n`;
        content += `Calories: ${meal.calories} | Protein: ${meal.protein}g | Carbs: ${meal.carbs}g | Fat: ${meal.fat}g\n`;
        
        content += `Ingredients:\n`;
        meal.ingredients.forEach(ingredient => {
          content += `- ${ingredient}\n`;
        });
        
        content += `Instructions: ${meal.instructions}\n\n`;
      });
      
      content += `\n`;
    });
    
    // Create blob and download
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nutriplan_meal_plan.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-16 h-16 border-t-4 border-green-500 border-solid rounded-full animate-spin"></div>
        <h2 className="mt-6 text-xl font-semibold text-gray-900">Generating your personalized meal plan...</h2>
        <p className="mt-2 text-gray-600">This may take a moment as we craft the perfect plan for your needs.</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-red-600 text-center mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <h2 className="mt-4 text-xl font-bold">{error}</h2>
        </div>
        <button
          onClick={() => navigate('/quiz')}
          className="mt-4 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Try Again
        </button>
      </div>
    );
  }
  
  if (!mealPlan) {
    return null;
  }
  
  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-3">Your Personalized 7-Day Meal Plan</h1>
          <p className="text-lg text-gray-600">Follow this plan to achieve your health and nutrition goals</p>
        </div>
        
        <div className="mx-auto max-w-5xl">
          {/* Daily Nutritional Info */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Daily Nutritional Targets</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-green-50 rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Calories</div>
                <div className="text-2xl font-bold text-green-700">{mealPlan.calories}</div>
              </div>
              <div className="bg-blue-50 rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Protein</div>
                <div className="text-2xl font-bold text-blue-700">{mealPlan.protein}g</div>
              </div>
              <div className="bg-yellow-50 rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Carbs</div>
                <div className="text-2xl font-bold text-yellow-700">{mealPlan.carbs}g</div>
              </div>
              <div className="bg-red-50 rounded-lg p-4 text-center">
                <div className="text-sm text-gray-500">Fat</div>
                <div className="text-2xl font-bold text-red-700">{mealPlan.fat}g</div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button
              onClick={handleDownload}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <Download className="h-5 w-5 mr-2 text-gray-500" />
              Download Plan
            </button>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <PrinterIcon className="h-5 w-5 mr-2 text-gray-500" />
              Print Plan
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'My NutriPlan Meal Plan',
                    text: 'Check out my personalized meal plan from NutriPlan!',
                    url: window.location.href,
                  });
                } else {
                  alert('Sharing is not supported in your browser.');
                }
              }}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <Share2 className="h-5 w-5 mr-2 text-gray-500" />
              Share Plan
            </button>
          </div>
          
          {/* Meal Plan */}
          <div className="space-y-6">
            {mealPlan.days.map((day) => (
              <div key={day.day} className="border rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleDay(day.day)}
                  className="w-full px-6 py-4 bg-white flex justify-between items-center hover:bg-gray-50"
                >
                  <h3 className="text-lg font-medium text-gray-900">{day.day}</h3>
                  {expandedDay === day.day ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                
                {expandedDay === day.day && (
                  <div className="px-6 py-4 bg-gray-50">
                    <div className="space-y-2">
                      {day.meals.map((meal) => (
                        <MealCard 
                          key={meal.type}
                          meal={meal}
                          onClick={() => toggleMeal(day.day, meal.type)}
                          isExpanded={expandedMeals[day.day]?.includes(meal.type) || false}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          {/* Food Image Gallery */}
          <div className="mt-12">
            <h2 className="text-xl font-semibold text-gray-900 mb-6 text-center">Meal Inspiration</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1447078806655-40579c2520d6?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwbWVhbCUyMHByZXAlMjBmb29kJTIwdmFyaWV0eXxlbnwwfHx8fDE3NDcyODE3MTh8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                  alt="Healthy meal preparation with variety of foods" 
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxoZWFsdGh5JTIwbWVhbCUyMHByZXAlMjBmb29kJTIwdmFyaWV0eXxlbnwwfHx8fDE3NDcyODE3MTh8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                  alt="Healthy dessert options" 
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1512149177596-f817c7ef5d4c?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxoZWFsdGh5JTIwbWVhbCUyMHByZXAlMjBmb29kJTIwdmFyaWV0eXxlbnwwfHx8fDE3NDcyODE3MTh8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
                  alt="Healthy snack options" 
                  className="w-full h-64 object-cover rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Results;
  