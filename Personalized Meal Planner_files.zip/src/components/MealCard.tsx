import  { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Meal } from '../types';

type MealCardProps = {
  meal: Meal;
  onClick: () => void;
  isExpanded: boolean;
};

const MealCard = ({ meal, onClick, isExpanded }: MealCardProps) => {
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden mb-4">
      <div 
        className="px-4 py-4 cursor-pointer flex justify-between items-center"
        onClick={onClick}
      >
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{meal.type}: {meal.name}</h3>
          <div className="mt-1 text-sm text-gray-600">
            {meal.calories} calories | {meal.protein}g protein | {meal.carbs}g carbs | {meal.fat}g fat
          </div>
        </div>
        <div>
          {isExpanded ? (
            <ChevronUp className="h-5 w-5 text-gray-500" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-4 py-4 border-t border-gray-200 bg-gray-50">
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-2">Ingredients</h4>
            <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
              {meal.ingredients.map((ingredient, idx) => (
                <li key={idx}>{ingredient}</li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-2">Instructions</h4>
            <p className="text-sm text-gray-600">{meal.instructions}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MealCard;
  