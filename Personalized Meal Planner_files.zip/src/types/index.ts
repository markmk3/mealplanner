export  type Meal = {
  type: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  ingredients: string[];
  instructions: string;
};

export type DayPlan = {
  day: string;
  meals: Meal[];
};

export type MealPlan = {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  days: DayPlan[];
};
  