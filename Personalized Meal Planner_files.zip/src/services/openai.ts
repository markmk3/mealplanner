import  { MealPlan } from '../types';

interface UserData {
  name: string;
  age: string;
  gender: string;
  weight: string;
  height: string;
  goal: string;
  activityLevel: string;
  dietaryRestrictions: string[];
  allergies: string[];
  mealPreference: string;
}

export async function generateMealPlan(userData: UserData): Promise<MealPlan> {
  try {
    // In a production app, this would make an API call to OpenAI
    console.log("Generating meal plan for:", userData);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return getFallbackMealPlan(userData);
  } catch (error) {
    console.error("Error in generateMealPlan:", error);
    throw new Error("Failed to generate meal plan");
  }
}

function getFallbackMealPlan(userData: any): MealPlan {
  const goalCalories = 
    userData.goal === 'weight-loss' ? 1800 : 
    userData.goal === 'muscle-gain' ? 2500 : 2200;
  
  const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  
  // Different breakfast recipes for each day
  const breakfasts = [
    {
      name: 'Greek Yogurt with Berries and Granola',
      ingredients: [
        'Greek yogurt (1 cup)',
        'Mixed berries (1/2 cup)',
        'Granola (1/4 cup)',
        'Honey (1 tsp)'
      ],
      instructions: 'Mix all ingredients in a bowl and enjoy.'
    },
    {
      name: 'Avocado Toast with Poached Egg',
      ingredients: [
        'Whole grain bread (2 slices)',
        'Avocado (1/2)',
        'Eggs (2)',
        'Cherry tomatoes (1/4 cup, halved)',
        'Salt, pepper, and red pepper flakes to taste'
      ],
      instructions: 'Toast bread. Mash avocado and spread on toast. Poach eggs for 3 minutes. Top toast with eggs and tomatoes. Season to taste.'
    },
    {
      name: 'Banana Oatmeal with Walnuts',
      ingredients: [
        'Rolled oats (1/2 cup)',
        'Milk or plant-based alternative (1 cup)',
        'Banana (1, sliced)',
        'Walnuts (2 tbsp, chopped)',
        'Cinnamon (1/4 tsp)',
        'Maple syrup (1 tsp)'
      ],
      instructions: 'Cook oats with milk according to package instructions. Top with banana slices, walnuts, cinnamon, and a drizzle of maple syrup.'
    },
    {
      name: 'Veggie Omelette with Toast',
      ingredients: [
        'Eggs (3)',
        'Bell pepper (1/4 cup, diced)',
        'Spinach (1/2 cup)',
        'Onion (2 tbsp, diced)',
        'Whole grain toast (1 slice)',
        'Olive oil (1 tsp)',
        'Salt and pepper to taste'
      ],
      instructions: 'Whisk eggs in a bowl. Heat oil in a pan and sauté vegetables until soft. Pour eggs over vegetables and cook until set. Fold in half and serve with toast.'
    },
    {
      name: 'Protein Smoothie Bowl',
      ingredients: [
        'Frozen mixed berries (1 cup)',
        'Banana (1/2)',
        'Protein powder (1 scoop)',
        'Almond milk (1/2 cup)',
        'Toppings: chia seeds, sliced fruit, coconut flakes'
      ],
      instructions: 'Blend berries, banana, protein powder, and almond milk until smooth. Pour into a bowl and add toppings.'
    },
    {
      name: 'Cottage Cheese with Fruit and Nuts',
      ingredients: [
        'Cottage cheese (1 cup)',
        'Pineapple chunks (1/2 cup)',
        'Almonds (2 tbsp, sliced)',
        'Honey (1 tsp)'
      ],
      instructions: 'Place cottage cheese in a bowl. Top with pineapple, almonds, and a drizzle of honey.'
    },
    {
      name: 'Whole Grain Pancakes with Berries',
      ingredients: [
        'Whole grain pancake mix (1/2 cup)',
        'Milk (1/3 cup)',
        'Egg (1)',
        'Mixed berries (1/2 cup)',
        'Maple syrup (1 tbsp)'
      ],
      instructions: 'Mix pancake batter according to package instructions. Cook on a griddle until golden brown. Top with berries and maple syrup.'
    }
  ];
  
  // Different lunch recipes for each day
  const lunches = [
    {
      name: 'Grilled Chicken Salad',
      ingredients: [
        'Grilled chicken breast (4 oz)',
        'Mixed greens (2 cups)',
        'Cherry tomatoes (1/2 cup)',
        'Cucumber (1/2 cup, sliced)',
        'Olive oil (1 tbsp)',
        'Balsamic vinegar (1 tbsp)',
        'Salt and pepper to taste'
      ],
      instructions: 'Combine all ingredients in a large bowl. Drizzle with olive oil and balsamic vinegar.'
    },
    {
      name: 'Quinoa Bowl with Roasted Vegetables',
      ingredients: [
        'Quinoa (1/2 cup, cooked)',
        'Bell peppers (1/2 cup, roasted)',
        'Zucchini (1/2 cup, roasted)',
        'Chickpeas (1/3 cup)',
        'Feta cheese (2 tbsp)',
        'Lemon-tahini dressing (2 tbsp)'
      ],
      instructions: 'Place cooked quinoa in a bowl. Top with roasted vegetables, chickpeas, and feta. Drizzle with lemon-tahini dressing.'
    },
    {
      name: 'Turkey and Avocado Wrap',
      ingredients: [
        'Whole grain tortilla (1 large)',
        'Turkey slices (3 oz)',
        'Avocado (1/2, sliced)',
        'Spinach (1 cup)',
        'Hummus (2 tbsp)',
        'Red onion (2 tbsp, sliced)'
      ],
      instructions: 'Spread hummus on tortilla. Layer with turkey, avocado, spinach, and red onion. Roll up tightly and cut in half.'
    },
    {
      name: 'Mediterranean Tuna Salad',
      ingredients: [
        'Canned tuna in water (4 oz, drained)',
        'Cherry tomatoes (1/2 cup, halved)',
        'Cucumber (1/2 cup, diced)',
        'Kalamata olives (10, pitted and sliced)',
        'Red onion (2 tbsp, diced)',
        'Olive oil (1 tbsp)',
        'Lemon juice (1 tbsp)',
        'Mixed greens (2 cups)'
      ],
      instructions: 'Mix tuna with tomatoes, cucumber, olives, and red onion. Dress with olive oil and lemon juice. Serve over mixed greens.'
    },
    {
      name: 'Lentil Soup with Whole Grain Bread',
      ingredients: [
        'Lentils (1/2 cup, cooked)',
        'Carrots (1/4 cup, diced)',
        'Celery (1/4 cup, diced)',
        'Onion (1/4 cup, diced)',
        'Vegetable broth (1 cup)',
        'Whole grain bread (1 slice)',
        'Olive oil (1 tsp)',
        'Garlic (1 clove, minced)',
        'Cumin and paprika to taste'
      ],
      instructions: 'Sauté onion, carrot, celery, and garlic in olive oil. Add lentils, broth, and spices. Simmer until vegetables are tender. Serve with whole grain bread.'
    },
    {
      name: 'Black Bean and Sweet Potato Bowl',
      ingredients: [
        'Black beans (1/2 cup, cooked)',
        'Sweet potato (1 medium, roasted)',
        'Brown rice (1/3 cup, cooked)',
        'Avocado (1/4, sliced)',
        'Lime juice (1 tsp)',
        'Cilantro (1 tbsp, chopped)',
        'Cumin and chili powder to taste'
      ],
      instructions: 'Layer brown rice, black beans, and roasted sweet potato cubes in a bowl. Top with avocado slices, lime juice, cilantro, and spices.'
    },
    {
      name: 'Chicken and Vegetable Stir Fry',
      ingredients: [
        'Chicken breast (4 oz, sliced)',
        'Bell peppers (1/2 cup, sliced)',
        'Broccoli (1/2 cup, florets)',
        'Snap peas (1/4 cup)',
        'Brown rice (1/3 cup, cooked)',
        'Soy sauce (1 tbsp, low sodium)',
        'Ginger (1 tsp, grated)',
        'Garlic (1 clove, minced)',
        'Sesame oil (1 tsp)'
      ],
      instructions: 'Stir-fry chicken in sesame oil until cooked through. Add vegetables, ginger, and garlic, cook until tender-crisp. Add soy sauce and serve over brown rice.'
    }
  ];
  
  // Different dinner recipes for each day
  const dinners = [
    {
      name: 'Baked Salmon with Quinoa and Roasted Vegetables',
      ingredients: [
        'Salmon fillet (5 oz)',
        'Quinoa (1/2 cup, cooked)',
        'Broccoli (1 cup)',
        'Bell peppers (1/2 cup, sliced)',
        'Olive oil (1 tbsp)',
        'Lemon (1/2)',
        'Garlic (2 cloves)',
        'Herbs and spices to taste'
      ],
      instructions: 'Preheat oven to 400°F. Place salmon on baking sheet, season with olive oil, lemon, garlic, and spices. Roast vegetables with olive oil. Cook quinoa according to package instructions. Bake salmon for 12-15 minutes.'
    },
    {
      name: 'Turkey Meatballs with Zucchini Noodles',
      ingredients: [
        'Ground turkey (4 oz)',
        'Zucchini (2, spiralized)',
        'Marinara sauce (1/2 cup)',
        'Garlic (2 cloves, minced)',
        'Italian herbs (1 tsp)',
        'Parmesan cheese (2 tbsp, grated)',
        'Breadcrumbs (2 tbsp, whole wheat)',
        'Egg (1/2, beaten)',
        'Olive oil (1 tbsp)'
      ],
      instructions: 'Mix turkey with breadcrumbs, egg, half the garlic, and Italian herbs. Form into meatballs and bake at 375°F for 20 minutes. Sauté zucchini noodles with remaining garlic in olive oil. Top with marinara sauce and meatballs. Sprinkle with Parmesan.'
    },
    {
      name: 'Vegetable and Chickpea Curry',
      ingredients: [
        'Chickpeas (1/2 cup, cooked)',
        'Cauliflower (1 cup, florets)',
        'Spinach (1 cup)',
        'Onion (1/4 cup, diced)',
        'Coconut milk (1/2 cup)',
        'Curry powder (1 tsp)',
        'Turmeric (1/2 tsp)',
        'Ginger (1 tsp, grated)',
        'Garlic (2 cloves, minced)',
        'Brown rice (1/3 cup, cooked)'
      ],
      instructions: 'Sauté onion, garlic, and ginger until fragrant. Add spices and cook for 1 minute. Add cauliflower and coconut milk, simmer until tender. Stir in chickpeas and spinach. Serve over brown rice.'
    },
    {
      name: 'Grilled Steak with Sweet Potato and Green Beans',
      ingredients: [
        'Lean steak (4 oz)',
        'Sweet potato (1 medium)',
        'Green beans (1 cup)',
        'Olive oil (1 tbsp)',
        'Garlic (1 clove, minced)',
        'Rosemary (1 tsp, fresh)',
        'Salt and pepper to taste'
      ],
      instructions: 'Season steak with salt, pepper, and rosemary. Grill to desired doneness. Roast sweet potato until tender. Steam green beans and toss with olive oil and garlic.'
    },
    {
      name: 'Shrimp and Vegetable Stir-Fry',
      ingredients: [
        'Shrimp (4 oz, peeled and deveined)',
        'Brown rice (1/3 cup, cooked)',
        'Bell peppers (1/2 cup, sliced)',
        'Snow peas (1/2 cup)',
        'Carrots (1/4 cup, julienned)',
        'Garlic (2 cloves, minced)',
        'Ginger (1 tsp, grated)',
        'Low-sodium soy sauce (1 tbsp)',
        'Sesame oil (1 tsp)',
        'Scallions (2 tbsp, chopped)'
      ],
      instructions: 'Heat sesame oil in a wok. Add garlic and ginger, stir-fry until fragrant. Add vegetables and stir-fry until tender-crisp. Add shrimp and cook until pink. Stir in soy sauce and serve over brown rice. Garnish with scallions.'
    },
    {
      name: 'Stuffed Bell Peppers',
      ingredients: [
        'Bell peppers (2, halved and seeded)',
        'Lean ground beef (3 oz)',
        'Brown rice (1/3 cup, cooked)',
        'Onion (1/4 cup, diced)',
        'Tomato sauce (1/4 cup)',
        'Garlic (1 clove, minced)',
        'Italian seasoning (1 tsp)',
        'Mozzarella cheese (2 tbsp, shredded)'
      ],
      instructions: 'Preheat oven to 375°F. Cook beef with onion and garlic until browned. Stir in rice, tomato sauce, and seasonings. Fill pepper halves with mixture. Top with cheese. Bake for 25-30 minutes until peppers are tender.'
    },
    {
      name: 'Baked Cod with Roasted Root Vegetables',
      ingredients: [
        'Cod fillet (5 oz)',
        'Carrots (1/2 cup, chopped)',
        'Parsnips (1/2 cup, chopped)',
        'Sweet potato (1/2, chopped)',
        'Olive oil (1 tbsp)',
        'Lemon (1/2)',
        'Dill (1 tsp, fresh)',
        'Garlic (1 clove, minced)',
        'Salt and pepper to taste'
      ],
      instructions: 'Preheat oven to 400°F. Toss root vegetables with olive oil, salt, and pepper. Roast for 20 minutes. Place cod on a baking sheet, season with lemon, dill, garlic, salt, and pepper. Bake for 10-12 minutes until fish flakes easily.'
    }
  ];
  
  return {
    calories: goalCalories,
    protein: Math.round(goalCalories * 0.3 / 4), // 30% protein
    carbs: Math.round(goalCalories * 0.4 / 4), // 40% carbs
    fat: Math.round(goalCalories * 0.3 / 9), // 30% fat
    days: daysOfWeek.map((day, index) => ({
      day,
      meals: [
        {
          type: 'Breakfast',
          name: breakfasts[index].name,
          calories: Math.round(goalCalories * 0.25),
          protein: Math.round((goalCalories * 0.25) * 0.3 / 4),
          carbs: Math.round((goalCalories * 0.25) * 0.4 / 4),
          fat: Math.round((goalCalories * 0.25) * 0.3 / 9),
          ingredients: breakfasts[index].ingredients,
          instructions: breakfasts[index].instructions
        },
        {
          type: 'Lunch',
          name: lunches[index].name,
          calories: Math.round(goalCalories * 0.35),
          protein: Math.round((goalCalories * 0.35) * 0.4 / 4),
          carbs: Math.round((goalCalories * 0.35) * 0.3 / 4),
          fat: Math.round((goalCalories * 0.35) * 0.3 / 9),
          ingredients: lunches[index].ingredients,
          instructions: lunches[index].instructions
        },
        {
          type: 'Dinner',
          name: dinners[index].name,
          calories: Math.round(goalCalories * 0.4),
          protein: Math.round((goalCalories * 0.4) * 0.35 / 4),
          carbs: Math.round((goalCalories * 0.4) * 0.35 / 4),
          fat: Math.round((goalCalories * 0.4) * 0.3 / 9),
          ingredients: dinners[index].ingredients,
          instructions: dinners[index].instructions
        }
      ]
    }))
  };
}

// Function to use the OpenAI API with our proxy server
export async function generateMealPlanWithAPI(userData: UserData): Promise<MealPlan> {
  try {
    const prompt = `Generate a personalized 7-day meal plan for a ${userData.gender}, ${userData.age} years old, weighing ${userData.weight}kg, ${userData.height}cm tall, with ${userData.activityLevel} activity level. Their goal is ${userData.goal}. Dietary restrictions: ${userData.dietaryRestrictions.join(', ')}. Allergies: ${userData.allergies.join(', ')}. They prefer ${userData.mealPreference} meal schedule. Make sure to provide DIFFERENT recipes for each day of the week.`;
    
    const response = await fetch('https://hooks.jdoodle.net/proxy?url=https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a nutritionist and meal planning expert. Create meal plans with specific macros and ingredients."
          },
          {
            role: "user",
            content: prompt
          }
        ]
      })
    });

    const data = await response.json();
    
    // Parse the response from OpenAI
    // This is a simplified version - in real application you would properly parse the formatted response
    console.log("API Response:", data);
    
    // For now, return the fallback plan while we debug the API
    return getFallbackMealPlan(userData);
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    // Fall back to the local generation
    return getFallbackMealPlan(userData);
  }
}
  